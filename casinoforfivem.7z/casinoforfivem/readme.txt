place this in the server.cfg 

start blackjack
start casinoexterior
start casinointerior
start program-casino
start ruletka
start sloty


in the sql make sure you check the top row. make sure it matches your own item DB table.