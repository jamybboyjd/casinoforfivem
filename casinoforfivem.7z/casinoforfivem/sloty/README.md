# esx_slots

Converted from vrp_slots original post: https://forum.fivem.net/t/release-vrp-vrp-slots-5x3-slot-machine-animated-sound-effects/627146
Made by plesalex100
